
const express=require('express');
const sdk=require('microsoft-cognitiveservices-speech-sdk');
const fs=require('fs'),os=require('os'),path=require('path');
require('dotenv').config();

const app=express();
app.use(express.json({limit:'160mb'}));
app.use(express.static(path.join(__dirname,'public')));

const key=()=>process.env.AZURE_SPEECH_KEY||'';
const region=()=>process.env.AZURE_SPEECH_REGION||'';

const VOICES={
  us_female:{locale:'en-US',voice:'en-US-Ava:DragonHDLatestNeural'},
  us_male:{locale:'en-US',voice:'en-US-Andrew:DragonHDLatestNeural'},
  uk_female:{locale:'en-GB',voice:'en-GB-SoniaNeural'},
  uk_male:{locale:'en-GB',voice:'en-GB-RyanNeural'}
};

app.get('/api/status',(req,res)=>res.json({ready:Boolean(key()&&region())}));

app.post('/api/tts',(req,res)=>{
  if(!key()||!region()) return res.status(503).json({error:'service-not-configured'});
  const v=VOICES[String(req.body?.voiceId||'us_female')]||VOICES.us_female;
  const text=String(req.body?.text||'').trim();
  const style=String(req.body?.style||'warm');
  const slow=!!req.body?.slow;
  if(!text)return res.status(400).json({error:'missing-text'});
  try{
    const c=sdk.SpeechConfig.fromSubscription(key(),region());
    c.speechSynthesisLanguage=v.locale;
    c.speechSynthesisVoiceName=v.voice;
    c.setSpeechSynthesisOutputFormat(sdk.SpeechSynthesisOutputFormat.Audio24Khz48KBitRateMonoMp3);
    const syn=new sdk.SpeechSynthesizer(c);
    const esc=text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    let rate=slow?'-18%':style==='engaging'?'+4%':style==='executive'?'-8%':'-3%';
    let pitch=slow?'+1%':style==='engaging'?'+4%':style==='executive'?'0%':'+2%';
    const ssml=`<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="${v.locale}">
      <voice name="${v.voice}"><prosody rate="${rate}" pitch="${pitch}">${esc}</prosody></voice></speak>`;
    syn.speakSsmlAsync(ssml,r=>{
      syn.close();
      if(r.reason===sdk.ResultReason.SynthesizingAudioCompleted){
        res.set('Content-Type','audio/mpeg');res.send(Buffer.from(r.audioData));
      }else res.status(500).json({error:'tts-failed'});
    },()=>{syn.close();res.status(500).json({error:'tts-failed'})});
  }catch(e){res.status(500).json({error:'tts-failed'})}
});

function tokens(s){
  return String(s||'').toLowerCase()
    .replace(/[^\p{L}\p{N}'\s]/gu,' ')
    .split(/\s+/).filter(Boolean);
}
function levenshtein(a,b){
  const d=Array.from({length:a.length+1},()=>Array(b.length+1).fill(0));
  for(let i=0;i<=a.length;i++)d[i][0]=i;
  for(let j=0;j<=b.length;j++)d[0][j]=j;
  for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++)
    d[i][j]=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+(a[i-1]===b[j-1]?0:1));
  return d[a.length][b.length];
}
function weighted(items,key){
  const a=items.filter(x=>Number.isFinite(x[key]));
  const den=a.reduce((s,x)=>s+(x.weight||1),0);
  return den?a.reduce((s,x)=>s+x[key]*(x.weight||1),0)/den:0;
}
function coach(result){
  const tips=[];
  const serious=(result.issues||[]).filter(x=>x.accuracy<70 || x.errorType!=='None').slice(0,3);
  serious.forEach(x=>{
    let msg=`“${x.word}” pronunciation accuracy is ${Math.round(x.accuracy)}. Listen to the model word, repeat it slowly twice, then put it back into the full sentence.`;
    if(x.errorType==='Omission') msg=`“${x.word}” was omitted. Make sure the word is fully delivered in the correct position.`;
    if(x.errorType==='Insertion') msg=`An extra word was detected near “${x.word}”. Follow the official script exactly.`;
    if(x.errorType==='Mispronunciation') msg=`“${x.word}” was detected as mispronounced. Isolate the word first, then retry the full phrase naturally.`;
    tips.push(msg);
  });
  if(result.fluency<75) tips.push('Fluency is below target. Keep phrases connected and avoid unnecessary stops between short word groups.');
  if(result.prosody!==null && result.prosody<75) tips.push('Prosody is below target. Add clearer sentence stress and let your intonation rise and fall naturally instead of reading every word at the same level.');
  if(result.completeness<95) tips.push('Script completeness is below target. Recheck the official text for omitted, inserted, or changed words.');
  return [...new Set(tips)].slice(0,4);
}

app.post('/api/assess',(req,res)=>{
  if(!key()||!region()) return res.status(503).json({error:'service-not-configured'});
  const reference=String(req.body?.referenceText||'').trim();
  const audio=String(req.body?.audioBase64||'');
  const accent=req.body?.accent==='uk'?'uk':'us';
  if(!reference||!audio)return res.status(400).json({error:'missing-data'});

  const locale=accent==='uk'?'en-GB':'en-US';
  const prosodySupported=locale==='en-US';
  const tmp=path.join(os.tmpdir(),`showroom-${Date.now()}-${Math.random().toString(36).slice(2)}.wav`);
  fs.writeFileSync(tmp,Buffer.from(audio,'base64'));

  try{
    const c=sdk.SpeechConfig.fromSubscription(key(),region());
    c.speechRecognitionLanguage=locale;
    c.outputFormat=sdk.OutputFormat.Detailed;
    const ac=sdk.AudioConfig.fromWavFileInput(fs.readFileSync(tmp));
    const rec=new sdk.SpeechRecognizer(c,ac);
    const pa=new sdk.PronunciationAssessmentConfig(
      reference,
      sdk.PronunciationAssessmentGradingSystem.HundredMark,
      sdk.PronunciationAssessmentGranularity.Phoneme,
      true
    );
    if(prosodySupported) pa.enableProsodyAssessment=true;
    pa.applyTo(rec);

    const seg=[],texts=[],wordDetails=[]; let done=false;
    const finish=(obj,code=200)=>{
      if(done)return; done=true;
      try{rec.stopContinuousRecognitionAsync(()=>rec.close(),()=>rec.close())}catch{}
      try{fs.unlinkSync(tmp)}catch{}
      res.status(code).json(obj);
    };

    rec.recognized=(s,e)=>{
      if(e.result.reason!==sdk.ResultReason.RecognizedSpeech)return;
      texts.push(e.result.text||'');
      let j={}; try{j=JSON.parse(e.result.json)}catch{}
      const nb=j.NBest?.[0]||{};
      const p=nb.PronunciationAssessment||{};
      const ws=(nb.Words||[]).map(w=>({
        word:w.Word,
        accuracy:Number(w.PronunciationAssessment?.AccuracyScore??0),
        errorType:w.PronunciationAssessment?.ErrorType||'None',
        phonemes:(w.Phonemes||[]).map(ph=>({
          phoneme:ph.Phoneme,
          accuracy:Number(ph.PronunciationAssessment?.AccuracyScore??0)
        }))
      }));
      wordDetails.push(...ws);
      seg.push({
        accuracy:Number(p.AccuracyScore??0),
        fluency:Number(p.FluencyScore??0),
        prosody:prosodySupported?Number(p.ProsodyScore??0):null,
        weight:Math.max(1,ws.length)
      });
    };

    rec.canceled=(s,e)=>{
      if(e.reason===sdk.CancellationReason.Error)finish({error:'assessment-failed'},500);
    };

    rec.sessionStopped=()=>{
      const recognized=texts.join(' ').trim();
      const rw=tokens(reference), hw=tokens(recognized);
      const completeness=Math.max(0,Math.min(100,100*(1-levenshtein(rw,hw)/Math.max(1,rw.length))));
      const accuracy=weighted(seg,'accuracy');
      const fluency=weighted(seg,'fluency');
      const prosody=prosodySupported?weighted(seg,'prosody'):null;

      // Transparent whole-section overall score. No score is produced without Azure metrics.
      const overall=prosodySupported
        ? accuracy*.40 + fluency*.25 + prosody*.20 + completeness*.15
        : accuracy*.50 + fluency*.30 + completeness*.20;

      const issues=wordDetails
        .filter(w=>w.accuracy<80 || w.errorType!=='None')
        .sort((a,b)=>{
          const ea=a.errorType==='None'?1:0, eb=b.errorType==='None'?1:0;
          return ea-eb || a.accuracy-b.accuracy;
        })
        .slice(0,20);

      const result={
        provider:'Microsoft Azure Speech Pronunciation Assessment',
        locale,
        overall:Math.round(overall),
        accuracy:Math.round(accuracy),
        fluency:Math.round(fluency),
        prosody:prosody===null?null:Math.round(prosody),
        completeness:Math.round(completeness),
        prosodySupported,
        recognizedText:recognized,
        issues
      };
      result.feedback=coach(result);
      finish(result);
    };

    rec.startContinuousRecognitionAsync(()=>{},()=>finish({error:'assessment-failed'},500));
  }catch(e){
    try{fs.unlinkSync(tmp)}catch{}
    res.status(500).json({error:'assessment-failed'});
  }
});

app.listen(process.env.PORT||3000,()=>console.log(`Showroom AI Coach V9: http://localhost:${process.env.PORT||3000}`));
