#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "请先安装 Node.js LTS: https://nodejs.org/"
  read -p "按回车关闭..."
  exit 1
fi
if [ ! -f .env ]; then
  cp .env.example .env
  echo "首次使用：请在打开的 .env 中填写 Azure Speech Key 和 Region，然后保存。"
  open -e .env
  read -p "保存后按回车继续..."
fi
if [ ! -d node_modules ]; then npm install || exit 1; fi
(open "http://localhost:3000" >/dev/null 2>&1 &) 
npm start
