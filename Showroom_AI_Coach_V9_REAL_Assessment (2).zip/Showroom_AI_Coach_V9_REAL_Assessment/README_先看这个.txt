SHOWROOM AI COACH V9 — REAL ASSESSMENT

这版包含：
- 无学生账号 / 无密码
- 整段录音
- 自己录音回放
- 真实 Azure Speech Pronunciation Assessment
- Pronunciation Accuracy
- Fluency
- Completeness / script accuracy
- en-US Prosody
- Word-level issues
- 自动生成的针对性反馈
- 85+ PASS
- American / British
- Female / Male
- Warm / Engaging / Executive 标准讲解风格

关键原则：
没有 Azure 返回结果时，系统绝不生成任何分数，也没有随机备用分。

为什么不能双击 HTML 就得到真实分数：
真实评测必须通过服务器调用语音评测服务，否则 Azure Key 会暴露给学生。
最终给学生使用时，应部署一次。学生只打开网址即可，完全不需要账号、密码、Node、Azure。

老师/管理员只需在服务器后台配置一次：
AZURE_SPEECH_KEY
AZURE_SPEECH_REGION
